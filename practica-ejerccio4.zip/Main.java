importar java.util.Scanner;
clase pública Principal {
   
    private final long[] TARIFAS = {48, 67};
    int final privado TIPO_MOTO = 0;
    int final privado TIPO_CARRO = 1;
    

    escáner de teclado privado;
    recaudo largo privado;
    
  
    public static void main(String[] args){
        Parqueadero p = nuevo Parqueadero ();
    }
    
  
    público Principal (){
        
        int opción = 1;
        int horaE = 0;entrada
        int minE = 0;
        int horaS = 0;
        int minS = 0;salida y total de minutos
        int tipo;
        Valor largo;servicio
        String tmp;
        
      
        teclado = nuevo escáner (Sistema.in);
        recaudado = 0;
        
        while(opción != 2){
           
            System.out.println("+------------------------------------------------------+");
            System.out.println("| MENÚ PRINCIPAL |");
            System.out.println("+------------------------------------------------------+");
            System.out.println("| 1) Calcular valor del servicio. |");
            System.out.println("| 2) Salir del programa. |");
            System.out.println("+------------------------------------------------------+");
            Sistema.salida.println(":::::");
            System.out.printf( "Recaudado: $%d\n",recaudado);
            Sistema.salida.println(":::::");
            System.out.println("\nDigite su opción por favor: ");
            opcion = teclado.nextInt();
            if(opción == 1){
                hacer{
                    System.out.println("\nDigite la hora de entrada. HH:mm");
                    System.out.println("Ejemplo: 13:30");
                    tmp = teclado.siguiente()+":";
                    Scanner leerHora = new Scanner(tmp).useDelimiter(":");
                    horaE = leerHora.nextInt();
                    minE = leerHora.nextInt();
                    leerHora.close();
                }mientras(!horaValida(horaE,minE));
                hacer{
                    System.out.println("\nDigite la hora de salida. HH:mm");
                    System.out.println("Ejemplo: 16:45");
                    tmp = teclado.siguiente()+":";
                    Scanner leerHora = new Scanner(tmp).useDelimiter(":");
                    horaS = leerHora.nextInt();
                    minS = leerHora.nextInt();
                    leerHora.close();
                }while(!horaValida(horaS,minS) || horaS<horaE);
                
                tipo=3;
                while(tipo!=TIPO_MOTO && tipo!=TIPO_CARRO){
                    System.out.println("+----------------------+");
                    System.out.println("| Tipo de Vehículo |");
                    System.out.println("+----------------------+");
                    System.out.println("| 1) Moto |");
                    System.out.println("| 2) Carro |");
                    System.out.println("+----------------------+");
                    System.out.println("\nDigite su opción por favor: ");
                    tipo = teclado.nextInt()-1;
                }
                minS = calcularMinutos(horaE, minE, horaS, minS);
                valor = minS * TARIFAS[tipo];
                if(tipo == TIPO_MOTO){
                    System.out.println("\nServicio de parqueo de moto:");
                    System.out.printf("Tarifa por minuto $%d\n",TARIFAS[0]);
                }más{
                    System.out.println("\nServicio de parqueo de carro:");
                    System.out.printf("Tarifa por minuto $%d:\n",TARIFAS[1]);
                }
                System.out.printf("%d minutos = $%d\n\n",minS,valor);
                recaudo += valor;
            }
        }
    }
    
    public boolean horaValida(int hora, int min){
        volver (hora>=0&&hora<24)&&(min>=0&&min<60);
    }
    
    public int calcularMinutos(int hIni, int mIni, int hFin, int mFin){
        volver (mFin - mIni) + (hFin - hIni) * 60;
    }
}
Pie de página
© 2022 GitHub, Inc.
Pie de página de navegación
Términos
Privacidad
Seguridad
Estado
Documentos