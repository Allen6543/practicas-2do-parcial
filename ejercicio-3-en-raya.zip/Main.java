importar java.util.Scanner;
importar java.util.concurrent.ThreadLocalRandom;

clase pública Principal {
    int estático final FILAS = 3;
    final static int COLUMNAS = 3;
    carácter estático final JUGADOR_X = 'X';
    carácter estático final JUGADOR_O = 'O';
    carácter estático final JUGADOR_CPU_O = JUGADOR_O;
    carácter estático final ESPACIO_VACIO = ' ';
    int estático final CONTEO_PARA_GANAR = 3;
    // Modos de juego
    final static int JUGADOR_JUGADOR = 1;
    final static int JUGADOR_CPU = 2;
    int estático final CPU_CPU = 3;
    // Para leer el teclado
    escáner estático final sc = nuevo escáner (System.in);

    // Clona la matriz. Útil para las simulaciones que se hacen, así no se modifica el tablero original
    static char[][] clonarMatriz(char[][] tableroOriginal) {
        char[][] copia = new char[FILAS][COLUMNAS];
        para (int y = 0; y < FILAS; y++) {
            for (int x = 0; x < COLUMNAS; x++) {
                copia[y][x] = tableroOriginal[y][x];
            }
        }
        devolver copia;
    }

    // Establece el tablero en espacios vacíos
    static void limpiarTablero(char[][] tablero) {
        int y;
        para (y = 0; y < FILAS; y++) {
            intx;
            para (x = 0; x < COLUMNAS; x++) {
                tablero[y][x] = ESPACIO_VACIO;
            }
        }
    }

    // Imprima el tablero de juego
    static void imprimirTablero(char[][] tablero) {
        Sistema.out.print("\n");
        int y;
        intx;
        // Imprimir encabezado
        Sistema.out.print("| ");
        para (x = 0; x < COLUMNAS; x++) {
            Sistema.salida.printf("|%d", x + 1);
        }
        Sistema.out.print("|\n");
        para (y = 0; y < FILAS; y++) {
            Sistema.salida.printf("|%d", y + 1);
            para (x = 0; x < COLUMNAS; x++) {
                System.out.printf("|%c", tablero[y][x]);
            }
            Sistema.out.print("|\n");
        }
    }

    // Indica si el tablero esta vacio en las coordenadas indicadas
    coordenadasVacías booleanas estáticas(int y, int x, char[][] tablero) {
        return tablero[y][x] == ESPACIO_VACIO;
    }

    // Coloca la X o O en las coordenadas especificadas
    static void colocarPieza(int y, int x, char pieza, char[][] tablero) {
        si (y < 0 || y >= FILAS) {
            System.out.print("Fila incorrecta");
            devolver;
        }

        si (x < 0 || x >= COLUMNAS) {
            System.out.print("Columna incorrecta");
            devolver;
        }
        if (pieza != JUGADOR_O && pieza != JUGADOR_X) {
            System.out.printf("La pieza debe ser %co %c", JUGADOR_O, JUGADOR_X);
            devolver;
        }
        if (!coordenadasVacías(y, x, tablero)) {
            System.out.print("Coordenadas ya ocupadas");
            devolver;
        }
        tablero[y][x] = pieza;
    }
    /*
    Funciones de conteo. Simplemente cuentan con piezas del mismo jugador están
    alineadas
    */

    static int contarHaciaArriba(int x, int y, char jugador, char[][] tablero) {
        int yInicio = (y - CONTEO_PARA_GANAR >= 0) ? y - CONTEO_PARA_GANAR+1:0;
        contador int = 0;
        for (; yInicio <= y; yInicio++) {
            if (tablero[yInicio][x] == jugador) {
                contador++;
            } más {
                contador = 0;
            }
        }
        volver contador;
    }

    static int contarHaciaDerecha(int x, int y, char jugador, char[][] tablero) {
        int xFin = (x + CONTEO_PARA_GANAR < COLUMNAS) ? x + CONTEO_PARA_GANAR - 1 : COLUMNAS - 1;
        contador int = 0;
        para (; x <= xFin; x++) {
            if (tablero[y][x] == jugador) {
                contador++;
            } más {
                contador = 0;
            }
        }
        volver contador;
    }

    static int contarHaciaArribaDerecha(int x, int y, char jugador, char[][] tablero) {
        int xFin = (x + CONTEO_PARA_GANAR < COLUMNAS) ? x + CONTEO_PARA_GANAR - 1 : COLUMNAS - 1;
        int yInicio = (y - CONTEO_PARA_GANAR >= 0) ? y - CONTEO_PARA_GANAR+1:0;
        contador int = 0;
        while (x <= xFin && yInicio <= y) {
            if (tablero[y][x] == jugador) {
                contador++;
            } más {
                contador = 0;
            }
            x++;
            y--;
        }
        volver contador;
    }

    static int contarHaciaAbajoDerecha(int x, int y, char jugador, char[][] tablero) {
        int xFin = (x + CONTEO_PARA_GANAR < COLUMNAS) ? x + CONTEO_PARA_GANAR - 1 : COLUMNAS - 1;
        int yFin = (y + CONTEO_PARA_GANAR < FILAS) ? y + CONTEO_PARA_GANAR - 1 : FILAS - 1;
        contador int = 0;
        while (x <= xFin && y <= yFin) {
            if (tablero[y][x] == jugador) {
                contador++;
            } más {
                contador = 0;
            }
            x++;
            y++;
        }
        volver contador;
    }

    // Indica si el jugador gana
    static boolean comprobarSiGana(char jugador, char[][] tablero) {
        int y;
        para (y = 0; y < FILAS; y++) {
            intx;
            para (x = 0; x < COLUMNAS; x++) {
                si (
                        contarHaciaArriba(x, y, jugador, tablero) >= CONTEO_PARA_GANAR ||
                                contarHaciaDerecha(x, y, jugador, tablero) >= CONTEO_PARA_GANAR ||
                                contarHaciaArribaDerecha(x, y, jugador, tablero) >= CONTEO_PARA_GANAR ||
                                contarHaciaAbajoDerecha(x, y, jugador, tablero) >= CONTEO_PARA_GANAR) {
                    devolver verdadero;
                }
            }
        }
        // Terminamos de recorrer y no conectar
        falso retorno;
    }

    // Devuelve el jugador contrario al que se le pasa. Es decir, le das un O y te devuelve el X
    static char opuestoDe(char jugador) {
        if (jugador == JUGADOR_O) {
            volver JUGADOR_X;
        } más {
            volver JUGADOR_O;
        }
    }

    // Imprima algo que el CPU "dice"
    static void hablar(String mensaje, char jugador) {
        System.out.printf("\nCPU (%c) dice: %s\n\n", jugador, mensaje);
    }

    // debería llamarse después de verificar si alguien gana
    // Indica si hay un empate
    empate booleano estático(char[][] tableroOriginal) {
        int y;
        para (y = 0; y < FILAS; y++) {
            intx;
            para (x = 0; x < COLUMNAS; x++) {
                // Si hay al menos un espacio vacío se dice que no hay empate
                if (tableroOriginal[y][x] == ESPACIO_VACIO) {
                    falso retorno;
                }
            }
        }
        devolver verdadero;
    }

    // Devuelve un número aleatorio en un rango, incluyendo los límites
    public static int aleatorioEnRango(int minimo, int maximo) {
        // nextInt regresa en rango pero con límite superior exclusivo, por eso sumamos 1
        devuelve ThreadLocalRandom.current().nextInt(minimo, maximo + 1);
    }

    // Devuelve las coordenadas válidas
    static int[] obtenerCoordenadasAleatorias(char jugador, char[][] tableroOriginal) {
        entero x, y;
        hacer {
            x = ocasionalEnRango(0, COLUMNAS - 1);
            y = ocasionalmente en rango(0, FILAS - 1);
        } while (!coordenadasVacías(y, x, tableroOriginal));
        devuelve nuevo int[]{x, y};
    }

    // Devuelve las coordenadas en las que se puede ganar, o -1 y -1 si no se puede ganar
    static int[] coordenadasParaGanar(char jugador, char[][] tableroOriginal) {
        entero y, x;
        para (y = 0; y < FILAS; y++) {
            para (x = 0; x < COLUMNAS; x++) {
                char[][] copiaTablero = clonarMatriz(tableroOriginal);
                if (coordenadasVacías(y,x,copiaTablero)) {
                    colocarPieza(y, x, jugador, copiaTablero);
                    if (comprobarSiGana(jugador, copiaTablero)) {
                        devuelve nuevo int[]{x, y};
                    }
                }
            }
        }
        devuelve nuevo int[]{-1, -1};
    }

    /*
Esta función cuenta y te dice el mayor puntaje, pero no te dice en cuál X ni cuál Y. Está pensada
para ser llamada desde otra funcion que lleva cuenta de X e Y
*/
    static int contarSinSaberCoordenadas(char jugador, char[][] copiaTablero) {
        int conteoMayor = 0;
        entero x, y;
        para (y = 0; y < FILAS; y++) {
            para (x = 0; x < COLUMNAS; x++) {
                // Colocamos y contamos el puntaje
                int conteoTemporal;
                conteoTemporal = contarHaciaArriba(x, y, jugador, copiaTablero);
                if (conteoTemporal > conteoMayor) {
                    conteoMayor = conteoTemporal;
                }
                conteoTemporal = contarHaciaArribaDerecha(x, y, jugador, copiaTablero);
                if (conteoTemporal > conteoMayor) {
                    conteoMayor = conteoTemporal;
                }

                conteoTemporal = contarHaciaDerecha(x, y, jugador, copiaTablero);
                if (conteoTemporal > conteoMayor) {
                    conteoMayor = conteoTemporal;
                }

                conteoTemporal = contarHaciaAbajoDerecha(x, y, jugador, copiaTablero);
                if (conteoTemporal > conteoMayor) {
                    conteoMayor = conteoTemporal;
                }
            }
        }
        volver conteoMayor;
    }

    /*
    Esta función complementaria a contar SinSaberCoordenadas. Te dice en qué X e Y el jugador [jugador]
    obtendrá el mayor puntaje si pone ahí su pieza
    */
    static int[]coordenadasParaMayorPuntaje(char jugador, char[][] tableroOriginal) {
        entero y, x;
        int conteoMayor = 0,
                xConteoMayor = -1,
                yConteoMayor = -1;
        para (y = 0; y < FILAS; y++) {
            para (x = 0; x < COLUMNAS; x++) {
                char[][] copiaTablero = clonarMatriz(tableroOriginal);
                if (!coordenadasVacías(y, x, copiaTablero)) {
                    Seguir;
                }
                // Colocamos y contamos el puntaje
                colocarPieza(y, x, jugador, copiaTablero);
                int conteoTemporal = contarSinSaberCoordenadas(jugador, copiaTablero);
                if (conteoTemporal > conteoMayor) {
                    conteoMayor = conteoTemporal;
                    yConteoMayor = y;
                    xConteoMayor = x;
                }
            }
        }
        return new int[]{conteoMayor, xConteoMayor, yConteoMayor};
    }

    // Hace que la CPU elija unas coordenadas para ganar
    static int[]CoordenadasCpu(char jugador, char[][] tablero) {
        hablar("Estoy pensando...", jugador);
    /*
    El orden en el que el CPU infiere las coordenadas que toma es:
    1. Ganar si se puede
    2. Hacer perder al oponente si está a punto de ganar
    3. Tomar el mejor movimiento del oponente (en donde obtienen el mayor puntaje)
    4. Tomar mi mejor movimiento (en donde obtengo mayor puntaje)
    5. Elegir la esquina superior izquierda (0,0)
    6. Coordenadas aleatorias
    */
        int y, x, conteoJugador, conteoOponente;
        int yOponente, xOponente;
        int[] coordenadas = new int[2];
        char oponente = oponenteDe(jugador);
        // 1
        coordenadas = coordenadasParaGanar(jugador, tablero);
        x = coordenadas[0];
        y = coordenadas[1];
        si (y != -1 && x != -1) {
            hablar("Ganar", jugador);
            devuelve nuevo int[]{x, y};
        }
        // 2
        coordenadas = coordenadasParaGanar(oponente, tablero);
        x = coordenadas[0];
        y = coordenadas[1];
        si (y != -1 && x != -1) {
            hablar("Tomar victoria de oponente", jugador);
            devuelve nuevo int[]{x, y};
        }
        // 3
        int[] coordenadasJugador = coordenadasParaMayorPuntaje(jugador, tablero);
        int[] coordenadasOponente = coordenadasParaMayorPuntaje(oponente, tablero);
        conteoJugador = coordenadasJugador[0];
        x = coordenadasJugador[1];
        y = coordenadasJugador[2];
        conteoOponente = coordenadasOponente[0];
        xOponente = coordenadasOponente[1];
        yOponente = coordenadasOponente[2];
        if (conteoOponente > conteoJugador) {
            hablar("Tomar puntaje mayor del oponente", jugador);
            return new int[]{xOponente, yOponente};
        } más si (conteoJugador > 0) {
            hablar("Tomar mi mayor puntaje", jugador);
            devuelve nuevo int[]{x, y};
        }
        // 4
        if (coordenadasVacías(0, 0, tablero)) {
            hablar("Tomar columna superior izquierda", jugador);
            devuelve nuevo int[]{0, 0};
        }
        // 5
        hablar("Coordenadas aleatorias", jugador);
        coordenadas = obtenerCoordenadasAleatorias(jugador, tablero);
        volver coordenadas;
    }

    // Devuelve un jugador aleatorio
    static char jugadorAleatorio() {
        if (aleatorioEnRango(0, 1) == 0) {
            volver JUGADOR_O;
        } más {
            volver JUGADOR_X;
        }
    }
    // Bucle principal del juego

    static void iniciarJuego(int modo) {
        if (modo != JUGADOR_JUGADOR && modo != JUGADOR_CPU && modo != CPU_CPU) {
            System.out.print("Modo de juego no permitido");
            devolver;
        }

        // Para que salgan cosas aleatorias
        // Iniciar tablero de juego
        char[][] tablero = new char[FILAS][COLUMNAS];
        // Y limpiarlo
        limpiarTablero(tablero);
        // Elegir jugador que inicia al azar
        char jugadorActual = jugadorAleatorio();
        System.out.printf("El jugador que inicia es: %c\n", jugadorActual);
        entero x = 0, y = 0;
        // Y alla vamos
        int[] coordenadas = new int[2];
        mientras (verdadero) {
            imprimirTablero(tablero);
            if (modo == JUGADOR_JUGADOR || (modo == JUGADOR_CPU && jugadorActual == JUGADOR_X)) {
                System.out.printf("Jugador %c. Ingresa coordenadas (x,y) para colocar la pieza\n", jugadorActual);
                hacer {
                    x = solicitarNumeroValido("Ingresa X: ", 1, COLUMNAS);
                    y = solicitarNumeroValido("Ingresa Y: ", 1, FILAS);
                    if (!coordenadasVacías(y - 1, x - 1, tablero)) {
                        System.out.println("Coordenadas ocupadas. Intento de nuevo");
                    }
                } while (!coordenadasVacías(y - 1, x - 1, tablero));
                // Al usuario se le solicitan números comenzando a contar en 1, pero en los arreglos comenzamos desde el 0
                // asi que necesitamos restaurar uno en ambas variables
                X--;
                y--;
            } else if (modo == CPU_CPU || jugadorActual == JUGADOR_CPU_O) {
                // Si es modo CPU contra CPU o es el turno del CPU, dejamos que las coordenadas las elija
                // el programa
                coordenadas = elegirCoordenadasCpu(jugadorActual, tablero);
                x = coordenadas[0];
                y = coordenadas[1];
            }
            // Sin importar cuál haya sido el modo, colocamos la pieza según las coordenadas elegidas

            colocarPieza(y, x, jugadorActual, tablero);
            // Puede que después de colocar la pieza el jugador gane o haya un empate, así que comprobamos
            if (comprobarSiGana(jugadorActual, tablero)) {
                imprimirTablero(tablero);
                System.out.printf("El jugador %c gana\n", jugadorActual);
                devolver;
            } else if (empate(tablero)) {
                imprimirTablero(tablero);
                System.out.print("Empatar");
                devolver;
            }
            // Si no, es turno del otro jugador
            jugadorActual = oponenteDe(jugadorActual);
        }
    }

    public static int solicitarNumeroValido(String mensaje, int minimo, int maximo) {
        numero int;
        mientras (verdadero) {
            System.out.println(mensaje);
            si (sc.hasNextInt()) {
                numero = sc.nextInt();
                if (numero >= minimo && numero <= maximo) {
                    devolver número;
                } más {
                    System.out.println("Número fuera de rango. Intento de nuevo");
                }
            } más {
                sc.siguiente();
            }
        }
    }


    public static void main(String[] args) {
        modo int;
        String menu = "1. Humano contra humano\n2. Humano contra CPU (El CPU juega como " + JUGADOR_CPU_O + ")\n3. CPU contra CPU\nElige: ";
        modo = solicitarNumeroValido(menu, 1, 3);
        iniciarJuego(modo);
        sc.cerrar();
    }
}